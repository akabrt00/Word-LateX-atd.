# TULPoster v Overleafu

## První spuštění

1. Na přehledu projektů v Overleafu zvolte **New Project > Upload Project** a nahrajte `tulposter-overleaf.zip`. ZIP předem nerozbalujte.
2. V **Settings > Compiler** vyberte **LuaLaTeX** a ponechte aktuální TeX Live. Jako hlavní dokument ponechte **main.tex** v kořeni projektu.
3. Klikněte na **Recompile**. Vpravo se zobrazí poster.

Pak už stačí upravovat text a znovu kliknout na Recompile. Nepotřebujete nic instalovat ani spouštět skripty na počítači.

## Co upravovat

| Soubor | Co zde měnit |
| --- | --- |
| `nastaveni.tex` | Název, autory, kontakt, počet sloupců, velikost písma, mezery a číslování. |
| `obsah.tex` | Vlastní texty, pořadí sekcí, obrázky, výsledky a tabulky. |
| `main.tex` | Formát A0/A1, orientaci, fakultu a jazyk. |
| `obrazky/` | Vlastní obrázky; soubor `prototyp.png` můžete nahradit. |

Soubory `tulposter.cls`, `tulposter-authoring.sty`, `tul.sty` a složka `assets/` obsahují společnou šablonu a identitu. Při běžné tvorbě je neupravujte.

## Přidání nebo přesunutí sekce

Zkopírujte celý blok do požadovaného sloupce. Číslo a formát nadpisu doplní šablona:

```tex
\begin{posterblock}{Název sekce}
Zde napište vlastní text.
\end{posterblock}
```

Tučný text: `\textbf{důležitá informace}`. Odrážky: `itemize`. Číslovaný postup: `postersteps`. Ukázky najdete přímo v `obsah.tex`.

## Sloupce, mezery a písmo

V `nastaveni.tex` měňte hodnoty v příkazu `\postersetup`:

```tex
columns=2,          % 2, 3 nebo 4 sloupce
density=normal,     % normal, compact nebo airy
spacing=spread,     % spread vyplní výšku, natural řadí bloky za sebou
numbered=true      % automatické číslování sekcí
```

Počet prostředí `postercol` v `obsah.tex` musí odpovídat hodnotě `columns`. Pro další sloupec zkopírujte celý úsek od `\begin{postercol}` po `\end{postercol}`. Šířky není potřeba počítat.

Volitelně lze přidat například `body-size=22pt`, `section-size=28pt` nebo `title-size=54pt`. Pokud se obsah nevejde, raději zkraťte text, zmenšete obrázek nebo zkuste `density=compact`.

## Obrázek a výsledek

Vlastní obrázek nahrajte v levém stromu souborů do složky `obrazky` a vložte:

```tex
\posterfigure{obrazky/prototyp.png}{Popisek obrázku.}

\begin{posterhighlight}[Hlavní výsledek]
O 18\% kratší doba zpracování
\end{posterhighlight}
```

Používejte přesnou velikost písmen v názvu souboru: `Prototyp.png` a `prototyp.png` jsou různé cesty. Pro vlastní názvy jsou nejjednodušší malá písmena bez mezer a diakritiky.

Pro QR kód: `\posteraccess{https://www.tul.cz}{Dokumentace projektu.}`. Pro zdroj pod obrázkem nebo výsledkem: `\postersource{Zdroj informace.}`.

## Práce s AI

Začněte tím, že v novém chatu Gemini nebo jiné AI přiložíte **`AI_INSTRUCTIONS.txt`**. Stejný obsah je i v `AI_INSTRUCTIONS.md`; stačí jeden z nich. Dokument vysvětluje, jak s vámi vést postupnou spolupráci a převádět běžné požadavky do TULPosteru. Zdrojový projekt nemusíte přikládat hned.

Případně připojte tuto krátkou zprávu:

> Přečti si tento návod a používej jej pro naši spolupráci na TULPosteru. Budu ti postupně říkat, co chci vytvořit nebo změnit. Zatím jen potvrď připravenost; potom ti popíšu svůj záměr.

Potom normálně pište například „chci poster k bakalářce“, „radši tři sloupce“ nebo „ten závěr zkrať“. AI má držet dosavadní zadání, ptát se jen na potřebné věci a rozlišovat konzultaci od tvorby souborů. Pro přesnou úpravu již existujícího posteru jí později přiložte aktuální `main.tex`, `nastaveni.tex` a `obsah.tex`, případně potřebné obrázky a další zdroje. Samotná přítomnost návodu v Overleafu neposkytuje jiné AI přístup k projektu.

Když chcete výsledek přenést do projektu, požádejte o celé změněné soubory. Vložte je zpět do Overleafu, spusťte Recompile a zkontrolujte PDF. Dokument je návod pro spolupráci; sám nepropojuje Gemini s Overleafem.

## Když se překlad zastaví

- Hláška o `fontspec`: zkontrolujte, že je vybraný **LuaLaTeX**.
- Hláška o počtu sloupců: porovnejte `columns` a počet prostředí `postercol`.
- Hláška `Column ... exceeds available poster height`: obsah daného sloupce je příliš dlouhý.
- Chybějící obrázek: zkontrolujte cestu, příponu a velikost písmen.

Fonty Inter a TUL Mono jsou přibalené v `assets/`. `latexmkrc` nepoužívá žádnou místní složku pro výstup. Ukázková fotografie je ilustrační AI obrázek, výsledky jsou demonstrační a QR kód vede na web TUL; nahraďte je vlastními podklady.

Toto je návrh šablony, nikoli oficiálně schválený styl TUL.

Oficiální návod Overleafu: https://docs.overleaf.com/managing-projects-and-files/uploading-a-project
