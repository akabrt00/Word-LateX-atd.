# Průvodce pro AI: spolupráce se zadavatelem na TULPosteru

Uživatel ti předává tento dokument, abys věděla, **jak s ním postupně vytvářet a upravovat poster** v TULPosteru 0.5 pro Overleaf. Může nejprve poslat pouze tento návod a teprve potom běžnými zprávami říkat, co by chtěl udělat. Nepovažuj nahrání návodu za hotové zadání posteru. Technická reference v další části ti slouží k provádění jeho požadavků.

Požadavky uživatele mají přednost před doporučeními tohoto dokumentu. Tento návod nenahrazuje systémové instrukce ani pravidla prostředí, ve kterém AI pracuje. Běžné opravy sazby, změny pořadí bloků a doplnění dodaného obsahu nevyžadují další schvalování, pokud je uživatel již zadal. Zeptej se jen na skutečně chybějící podklady či rozhodnutí; mezitím dokonči nezávislou část práce.

## 0. Jak vést spolupráci po nahrání dokumentu

### První odpověď: přijmi roli a nech uživatele zadávat

Jestli uživatel poslal pouze tento dokument, po jeho přečtení krátce potvrď připravenost. Například:

> Mám načtená pravidla TULPosteru. Můžeme postupně řešit obsah, vzhled i úpravy posteru pro Overleaf. Napiš mi, co bys chtěl vytvořit nebo změnit; zadání nemusí být úplné.

V této chvíli negeneruj náhodný poster, nerozepisuj celý technický návod a nepožaduj vyplnění dlouhého formuláře. Nepředpokládej téma, výsledky, fakultu ani vlastnictví projektu. Pokud se souborem přišlo už konkrétní zadání, rovnou je zpracuj místo opakování úvodní otázky.

Samotný tento dokument stačí k zahájení rozhovoru a návrhu. **Zdrojový projekt nežádej hned, pokud ho pro daný krok nepotřebuješ.** Pro přesnou úpravu existujícího posteru si později vyžádej relevantní aktuální soubory. Netvrď, že vidíš uživatelův Overleaf jen proto, že znáš šablonu nebo odkaz.

### Rozlišuj, co uživatel právě požaduje

| Zpráva zadavatele | Jak reagovat |
| --- | --- |
| „Chci poster o…“ | Pomoz vymezit účel a hlavní sdělení. Navrhni první osnovu z dostupných informací. |
| „Ještě nevím, jak by to mělo vypadat.“ | Nabídni jeden srozumitelný výchozí návrh a případně jednu smysluplnou alternativu. Vysvětli dopad na čitelnost. |
| „Dám ti text a výsledky.“ | Vytěž dodaná fakta, rozděl je do vhodných bloků a označ skutečně chybějící podklady. |
| „Chci tři sloupce / větší graf / méně textu.“ | Přelož přání do konkrétní úpravy rozvržení či obsahu. Zachovej ostatní domluvené vlastnosti a fakta. |
| „Zatím jen proberme možnosti.“ | Zůstaň u konzultace; nevypisuj nevyžádané zdrojové soubory. |
| „Teď mi dej soubory pro Overleaf.“ | Připrav aktuální zdroje podle dosavadní domluvy. Přesně napiš, které soubory vložit či nahradit. |
| „Tady je chyba / tady je náhled.“ | Oprav konkrétní problém proti poslední verzi, nerozjížděj celý projekt znovu. |

### Ptej se postupně a jen na potřebné věci

- Uživatel může psát obyčejně: „dej to vedle obrázku“, „tohle je moc dlouhé“, „udělej to čitelnější“. Nemusí znát LaTeX ani názvy komponent.
- V jedné odpovědi polož obvykle jednu, nanejvýš dvě otázky, které odblokují další krok. Neptej se znovu na informaci, kterou už zadavatel uvedl.
- Když lze začít návrhem struktury bez přesného formátu nebo obrázků, začni. Rozlišuj svůj pracovní návrh od potvrzeného požadavku.
- Neznámé výsledky, jména, fakultu, citace a adresy nedoplňuj odhadem. Mohou zůstat označené k doplnění. Chybějící obrázek může mít popsané místo, ale nevydávej neexistující soubor za přiložený.
- Běžné vratné úpravy proveď podle zadání. Nezdržuj každou změnu samostatnou otázkou, zda ji smíš udělat.

### Udržuj aktuální zadání napříč zprávami

Vycházej z dostupné konverzace a z poslední verze projektu. Průběžně si rozlišuj:

1. **Potvrzené zadání:** téma, účel, publikum, jazyk, formát, fakulta, obsah, styl a výslovně přijaté změny.
2. **Doložené podklady:** skutečné texty, čísla, zdroje, obrázky a adresy, které uživatel poskytl.
3. **Pracovní návrhy:** tvoje doporučení, která zadavatel zatím nepotvrdil.
4. **Otevřené body:** co je třeba doplnit před dokončením nebo před přesnou úpravou souborů.

Po důležité změně můžeš aktuální zadání krátce shrnout; nevypisuj dlouhý seznam po každé větě. Pozdější oprava nahrazuje starší rozhodnutí pouze v tom, co mění. Například „radši tři sloupce“ nemění téma, fakultu ani dodaná čísla. „Zkrať závěr“ neopravňuje přepisovat metodu nebo měnit výsledek.

Pokud chybí předchozí soubor nebo část konverzace, nepředstírej jejich znalost. Vyžádej si konkrétní aktuální podklad nebo se opři o dostupnou verzi. Požádá-li uživatel o předání do nového chatu, připrav krátké aktuální zadání a seznam posledních souborů.

### Převáděj přání do TULPosteru

| Přání uživatele | Typický zásah |
| --- | --- |
| Více nebo méně sloupců | `columns` a odpovídající počet prostředí `postercol`. Nestačí změnit jen číslo. |
| Kratší nebo přehlednější text | Zkrátit a rozdělit obsah v `obsah.tex`, zachovat význam, případně použít seznam. |
| Hlavní výsledek má být výraznější | Krátký `posterhighlight`, pokud je výsledek doložený. |
| Pravidelné mezery nebo využití celé výšky | Volba `spacing=natural` nebo `spacing=spread` podle obsahu. |
| Větší obrázek či graf | Upravit jeho skutečnou velikost nebo umístění a znovu posoudit zbytek stránky. Při širším obrázku změnit rozvržení; nezvětšovat slepě přes šířku sloupce. |
| Změna autorů, názvu či celkové velikosti textu | Upravit odpovídající položky v `nastaveni.tex`. |
| Jiný papír, orientace, jazyk nebo fakulta | Upravit volby v `main.tex`; zkontrolovat dopad na sazbu a vlastní jazyk obsahu. |

U nové tvorby lze začít návrhem bez zdrojových souborů. Až je potřeba upravovat skutečný projekt nebo připravit výstup, zjisti, zda má uživatel výchozí balíček. Před přesnou editací existujícího posteru potřebuješ aktuální příslušné soubory. Bez nich jasně rozlišuj návrh nové verze od úpravy něčeho, co jsi neviděla.

### Předávej výstupy v pravou chvíli

- Na konzultační otázku odpověz běžným jazykem. Kód nevypisuj automaticky po každém nápadu.
- Během navrhování a průběžných změn udržuj aktuální pracovní návrh. Celé zdroje vypiš až na žádost o soubory, export nebo dokončení, pokud uživatel nepožaduje jiný způsob práce. Samotné „dej tři sloupce“ není žádost o úplný výpis kódu.
- Když uživatel zadal realizaci a máš potřebné podklady, udělej ji. Samotná technická rada nenahrazuje požadovanou úpravu.
- Máš-li přístup k souborům, uprav je přímo. Jinak při předání vrať **celé obsahy změněných autorských souborů**, každý zvlášť s přesným názvem. Nevypouštěj části pomocí tří teček a nepřidávej Markdown značky dovnitř `.tex` souborů.
- U existujícího projektu vrať jen skutečně změněné soubory; zachovej zbytek. Při zakládání nového projektu dodej všechny tři autorské soubory a vysvětli, že společná třída, styly, fonty a obrázky zůstávají součástí celého balíčku.
- Připoj krátké vysvětlení změn a skutečně provedených kontrol. Když nemůžeš projekt přeložit, neoznačuj jej za ověřený v Overleafu.

### Příklad běžného rozhovoru

Toto je ilustrace způsobu spolupráce, nikoli skutečné zadání nebo vědecké výsledky:

> **Uživatel:** Chci poster k bakalářce o chlazení 3D tiskárny.\
> **AI:** Pomůžu ti z toho udělat poster. Pro koho ho připravuješ a jaké hlavní zjištění má ukázat?\
> **Uživatel:** K obhajobě, česky, A1. Text a měření ti pošlu.\
> **AI:** Zatím navrhuji dva sloupce: problém a postup vlevo, výsledky a závěr vpravo. Až pošleš podklady, naplníme je; čísla zatím nedoplňuji.\
> **Uživatel:** Tady je text a graf. Chci spíš tři sloupce a ten graf hodně velký.\
> **AI:** Zachovám A1 a češtinu. Rozdělím obsah do tří sloupců a pro graf navrhnu širší samostatný pás, aby zůstal čitelný. Pro přesnou úpravu mi teď pošli aktuální `main.tex`, `nastaveni.tex` a `obsah.tex`, pokud už projekt máš.\
> **Uživatel:** Je to zatím nová věc. Použiju tvůj výchozí balíček. Připrav mi ty soubory.\
> **AI:** Připravím tři autorské soubory pro výchozí balíček podle dodaného textu a grafu. Uvedu jeho skutečnou cestu a upozorním na podklady, které ještě chybějí.\
> **Uživatel:** Závěr je moc dlouhý, dej místo něj tři body.\
> **AI:** Zkrátím pouze závěr do tří bodů. Zachovám údaje, výsledky i ostatní rozvržení a vrátím aktualizovaný `obsah.tex`.

Další kapitoly jsou technická reference. Používej je podle právě řešeného požadavku, ne jako seznam otázek, které musí uživatel předem zodpovědět.

## 1. S jakým projektem pracuješ

Přenosný projekt pro Overleaf má hlavní dokument přímo v kořeni:

```text
main.tex                    formát papíru, orientace, fakulta a jazyk
nastaveni.tex               údaje projektu a společné nastavení vzhledu
obsah.tex                   text, sekce, sloupce a další obsah
tulposter.cls               společná třída TULPoster 0.5
tulposter-authoring.sty      jednoduché autorské rozhraní
tul.sty                     univerzitní identita
latexmkrc                   nastavení překladu
assets/                     přibalená loga a fonty
obrazky/                    vlastní obrazové podklady
NAPOVEDA.md                 návod pro člověka, pokud je přibalen
AI_INSTRUCTIONS.md          tento návod
AI_INSTRUCTIONS.txt         stejný návod jako textová příloha do chatu
```

Použij **LuaLaTeX**, současný TeX Live a hlavní dokument **main.tex**. Fonty a logo se načítají ze souborů v projektu. Nepřidávej závislost na systémových fontech, lokálních cestách Windows, PowerShellu, instalátoru ani shell escape. V Overleafu není potřeba spouštět místní skript.

Při běžné tvorbě upravuj tři soubory `main.tex`, `nastaveni.tex` a `obsah.tex`; vlastní obrázky přidávej do `obrazky/`. Názvy souborů a adresářů respektuj včetně velikosti písmen. Cesty používej relativně ke kořeni projektu a s lomítky `/`.

Tři upravené soubory samy nenahrazují celý balíček: při přenosu do nového projektu musí zůstat přibaleny také třída, oba styly, `assets/` a použité obrázky. Nevytvářej neúplný ZIP, který závisí na původním projektu mimo svůj kořen.

## 2. Základní pracovní pravidla

1. Přečti aktuální zadání a dostupné podklady. Existující autorské soubory přečti, pokud byly předány nebo jsou potřeba pro požadovanou úpravu; nejsou podmínkou počáteční konzultace. Při nejasnosti ověř podporovaný příkaz přímo v `tulposter.cls` nebo `tulposter-authoring.sty`, máš-li k nim přístup; nevymýšlej další volby.
2. Zachovej dodaná fakta, hodnoty, jména, citace a význam sdělení. Zkrať text jen tak, aby se nezměnil jeho význam.
3. Nejdříve stanov jednoduchou strukturu: problém, cíl, postup, hlavní výsledek a závěr. Nemusí mít všechny tyto názvy ani všechny tyto sekce.
4. Použij hotové komponenty. Neřeš běžné rozmístění absolutními souřadnicemi, ručními podíly šířek, zápornými mezerami či velkým množstvím `\vspace`.
5. Upravuj obsah a společné nastavení; při tvorbě jednoho posteru neměň společnou třídu a identitu.
6. Pokud nástroje dovolují překlad, přelož a zkontroluj skutečný výstup. Pokud ne, proveď kontrolu zdrojů a přesně uveď, co zůstává neověřené.

**Nevymýšlej výzkumné výsledky, metriky, citace, DOI, adresy dat ani cíle QR kódů.** Vzorová data a fotografie v původním balíčku jsou demonstrace. Chybějící hodnotu označ jako nedodanou nebo příslušný prvek vynech. Ukázkový QR kód na domovskou stránku TUL není odkaz na dokumentaci konkrétního projektu. QR kód vlož až pro skutečnou adresu dodanou či ověřenou pro daný účel.

## 3. `main.tex`: formát, fakulta a jazyk

```tex
\documentclass[a1paper,portrait,FP,screen]{tulposter}
\input{nastaveni}
\begin{document}
\input{obsah}
\end{document}
```

Podporované volby třídy:

| Oblast | Hodnoty | Výchozí hodnota třídy |
| --- | --- | --- |
| Papír | `a0paper`, `a1paper` | `a0paper` |
| Orientace | `portrait`, `landscape` | `portrait` |
| Jazyk | bez volby = čeština; `EN` = angličtina | čeština |
| Součást | `FS`, `FT`, `FP`, `EF`, `FUA`, `FM`, `FZS`, `CXI`; bez volby = TUL | TUL |
| Barvy | `screen`, `print` | `screen` |
| Vzhled | `refined` | `refined` |

Starší aliasy `FE` pro `EF` a `FA` pro `FUA` zůstávají přijímané. Historické volby `minimal`, `technical` a `editorial` pouze přecházejí na společný vzhled `refined`; nenabízej je jako odlišná současná témata.

Volba `EN` nepřekládá text uživatele. Texty v `nastaveni.tex` a `obsah.tex` napiš v požadovaném jazyce. Režim `print` mění vektorové barvy a text na definované CMYK hodnoty, ale sám neprovádí tiskovou ICC konverzi přiložených fotografií.

## 4. `nastaveni.tex`: skutečně podporované klíče

`\postersetup{...}` patří pouze před `\begin{document}`. Textové hodnoty zapisuj do složených závorek, zejména obsahují-li čárku.

```tex
\postersetup{
  title={Název projektu},
  author={Jana Nováková, Petr Dvořák},
  department={Název pracoviště},
  columns=2,
  density=normal,
  spacing=natural,
  numbered=true
}
```

| Klíč | Význam a přípustná hodnota | Výchozí stav třídy |
| --- | --- | --- |
| `title` | Název v jazyce posteru | upozornění na chybějící název |
| `subtitle` | Podtitul | prázdný |
| `author` | Autoři; klíč je v jednotném čísle | upozornění na chybějícího autora |
| `department` | Pracoviště | prázdné |
| `contact` | E-mail | prázdný |
| `website` | Web zobrazený v zápatí | prázdný |
| `event` | Akce nebo kontext posteru | prázdný |
| `columns` | Počet stejně širokých sloupců: `2`, `3` nebo `4` | `2` |
| `gap` | Nezáporná délka mezery mezi sloupci, např. `13mm` | A1: `13mm`; A0: `18mm` |
| `spacing` | `natural` nebo `spread` | `natural` |
| `numbered` | `true` nebo `false`; číslování sekcí | `false` |
| `density` | `normal`, `compact` nebo `airy`; mění mezeru mezi moduly | `normal` |
| `body-size` | Kladná velikost základního textu, např. `22pt` | A1: `22pt`; A0: `30pt` |
| `section-size` | Kladná velikost sekčních nadpisů | A1: `28pt`; A0: `34pt` |
| `title-size` | Kladná velikost hlavního názvu | A1: `54pt`; A0: `68pt` |
| `block-gap` | Přímá délka mezery mezi moduly | A1: `10mm`; A0: `13mm` |

Výchozí dodaná ukázka může nastavovat `spacing=spread` a `numbered=true` výslovně. To nejsou implicitní hodnoty samotné třídy. Zachovej již zvolené nastavení, pokud uživatel nežádá změnu.

Hustota nastavuje `block-gap`: A1 používá `7mm / 10mm / 14mm` pro `compact / normal / airy`, A0 používá `9mm / 13mm / 18mm`. Pokud se `density` a `block-gap` použijí opakovaně, platí poslední provedené nastavení. Hustota sama nezmenšuje písmo.

Při přímém nastavení velikosti písma dopočítá autorské rozhraní řádkování: `body-size` násobkem 1,3, `section-size` násobkem 1,24 a `title-size` násobkem 1,1. Změna se týká dané role; nemění automaticky velikost popisků ani všech ostatních prvků.

Nevkládej do `\postersetup` neexistující klíče jako `authors`, `faculty`, `paper`, `orientation`, `height` nebo `theme`. Fakulta a formát patří do `\documentclass`; výška je pokročilá místní volba `posterlayout`.

## 5. `obsah.tex`: sloupce a sekce

```tex
\begin{posterlayout}[columns=2]
  \begin{postercol}
    \begin{posterblock}{Problém}
      Text prvního sloupce.
    \end{posterblock}
  \end{postercol}
  \begin{postercol}
    \begin{posterblock}{Závěr}
      Text druhého sloupce.
    \end{posterblock}
  \end{postercol}
\end{posterlayout}
```

- Uvnitř jednoho `posterlayout` musí být přesně tolik prostředí `postercol`, kolik udává účinné `columns`. Změna `columns=3` vyžaduje také třetí sloupec ve zdroji.
- Šířky a mezery dopočítává šablona. `postercol` nemá argument se šířkou. Nezaměňuj jej se starším `postercolumn{0.485}`.
- Povolené místní volby `posterlayout` jsou jen `columns`, `gap`, `spacing` a `height`. Místní volba platí pro tento layout.
- `height=auto` je výchozí hodnota. Pro běžný poster nepřidávej ručně naměřenou výšku.
- `spacing=natural` řadí bloky za sebou s pevnými mezerami. Hodí se také pro více samostatných layoutů pod sebou.
- `spacing=spread` rozděluje volnou výšku mezi moduly a snaží se využít zbývající prostor před zápatím. Používej jej hlavně pro poslední nebo jediný layout; po jeho vyplnění nezbývá automaticky místo na další řádky obsahu.
- Více layoutů lze řadit za sebe. Celostránkový `posterblock` může stát mezi dvěma ukončenými layouty.
- `posterlayout` a `postercol` nevnořuj do sebe. Nekombinuj novou mřížku se staršími pevnými sloupci uvnitř jednoho sloupce.

Při `numbered=true` piš jen `\begin{posterblock}{Metoda}`. Nepřidávej ruční `01 /`, protože číslo doplní třída. Číslování pokračuje mezi sloupci i mezi layouty; samostatné zvýraznění se nečísluje.

## 6. Komponenty, které používat

### Text a seznamy

Používej běžné odstavce, `\textbf{důležité sdělení}`, `\emph{zdůraznění}` a `itemize`. Pro pracovní postup je k dispozici číslovaný seznam:

```tex
\begin{postersteps}
  \item Připravit podklady.
  \item Provést ověření.
  \item Vyhodnotit dodané výsledky.
\end{postersteps}
```

### Výsledek nebo klíčové sdělení

```tex
\begin{posterhighlight}[Hlavní sdělení]
Krátká ověřená informace z podkladů uživatele.
\end{posterhighlight}
```

`posterhighlight` může být samostatným modulem ve sloupci nebo součástí `posterblock`. Vnoření do bloku používá běžnou mezeru a neroztahuje prostředek sekce. Nevnořuj zvýraznění do dalšího zvýraznění. Pro jeden poster zpravidla stačí jeden výrazný hlavní výsledek.

### Tabulka

`postertable` přijímá jediný argument se specifikací sloupců a používá celou aktuální šířku. `X` je pružný textový sloupec; `l`, `r` a `c` mají přirozenou šířku. Příkazy `booktabs` už jsou načtené.

```tex
\begin{postertable}{Xl}
  \toprule
  Položka & Stav \\
  \midrule
  Zdrojová data & K doplnění \\
  \bottomrule
\end{postertable}
```

Použij `\toprule`, `\midrule`, `\bottomrule`, nikoli dekorativní svislé čáry. Tabulka s mnoha širokými číselnými sloupci se nemusí vejít; uprav její obsah či strukturu. Nevkládej ji do plovoucího prostředí `table`.

### Obrázek

```tex
\posterfigure{obrazky/prototyp.png}{Věcný popisek obrázku.}
```

Obrázek se automaticky přizpůsobí šířce sloupce. Volitelný první argument určuje šířku, například `\posterfigure[.85\linewidth]{obrazky/prototyp.png}{Popisek.}`. Ověř existenci souboru. Nepoužívej cestu k souboru, který uživatel nedodal.

Pokročilý celostránkový obrazový motiv lze vložit mimo layout:

```tex
\posterheroimage[150mm]{obrazky/prototyp.png}{Popisek obrazu.}
```

Tento příkaz obraz vystředí a ořízne tak, aby vyplnil požadovanou výšku i šířku. Nekresli text přes důležitý motiv. Výšku přizpůsob dostupnému místu; vložený obrázek ukrajuje prostor následujícím sloupcům.

### Zdroj a QR kód

```tex
\postersource{Zdroj: úplný údaj převzatý z ověřených podkladů.}
```

`\postersource` pouze formátuje dodaný zdroj. Nepřidává bibliografický záznam ani neověřuje pravdivost citace. Delší seznam zdrojů vlož do samostatného `posterblock`.

Pro skutečnou ověřenou adresu použij `\posteraccess{URL}{Vysvětlení cíle odkazu.}`; volitelný první argument mění velikost QR kódu, např. `[34mm]`. Vkládá kód a popisek do samostatného řádku. `\posterqrcode[34mm]{URL}` vkládá pouze kód a hodí se spíše pro pokročilou sazbu. Nedoplňuj smyšlenou URL, aby se zaplnilo prázdné místo.

### Omezení

- Uvnitř `postercol` nejsou podporované `\footnote` a `\footnotetext`; použij `\postersource` nebo sekci Literatura. Neobcházej toto omezení pomocí `\footnotemark`.
- Sloupce jsou neplovoucí bloky. Pro obrázky a tabulky používej přímé komponenty, ne plovoucí prostředí `figure` nebo `table`.
- Pro grafy lze vložit připravené PDF/PNG. Nativní graf `pgfplots` vyžaduje jeho načtení v preambuli; nevymýšlej nové grafové API třídy a nevyvozuj chybějící data.
- Doslovný výpis typu `verbatim` uvnitř prostředí zachycujícího celý obsah nepřidávej bez samostatného ověření kompatibility. Pro krátký příkaz obvykle stačí `\texttt{...}` se správně ošetřenými znaky.

## 7. Vizuální a obsahová kvalita

Udržuj krátké výstižné nadpisy, souvislé zarovnání a čitelnou hierarchii. Neplň každý prázdný prostor dalším textem; zvýrazni významný výsledek a potřebné důkazy. Dlouhou tabulku raději zjednoduš než nečitelně zmenši.

Zachovej `tul.sty`, logo, přesné barvy a fonty v `assets/`. Nerekonstruuj univerzitní značku jako obyčejný text, neměň její proporce a nenahrazuj identitu dalšími dekorativními prvky. Při změně fakulty použij podporovanou volbu třídy. Jde o návrh šablony; netvrď, že je oficiálně schválená TUL.

**Nezmenšuj automaticky celý poster ani základní písmo, aby se obsah násilně vešel.** Nejprve zkrať či přeskládej text, odstraň opakování, zmenši rozměr obrázku nebo použij `density=compact`. Formát papíru či čitelnostně významnou velikost písma měň podle zadání a změnu jasně popiš. Nezakrývej varování zápornými mezerami, ořezem textu či potlačením diagnostiky.

## 8. Minimální úplný příklad pro dva sloupce

Následující tři soubory jsou kompilovatelné v kořeni existujícího přenosného balíčku TULPoster 0.5. Nepotřebují vlastní obrázek, naměřené hodnoty ani QR odkaz. Nezaměňuj je s celým balíčkem bez podpůrných souborů.

### `main.tex`

```tex
\documentclass[a1paper,portrait,FP,screen]{tulposter}
\input{nastaveni}
\begin{document}
\input{obsah}
\end{document}
```

### `nastaveni.tex`

```tex
\postersetup{
  title={Název vlastního projektu},
  subtitle={Stručné vysvětlení cíle},
  author={Jméno autora},
  department={Název pracoviště},
  columns=2,
  density=normal,
  spacing=natural,
  numbered=true
}
```

### `obsah.tex`

```tex
\begin{posterlayout}
  \begin{postercol}
    \begin{posterblock}{Problém a cíl}
      Zde popište problém a otázku, na kterou projekt odpovídá.
      Důležité sdělení lze zvýraznit pomocí \textbf{tučného textu}.
    \end{posterblock}

    \begin{posterblock}{Postup}
      \begin{postersteps}
        \item Připravit potřebné podklady.
        \item Popsat způsob zpracování a ověření.
        \item Vyhodnotit skutečně získané výsledky.
      \end{postersteps}
    \end{posterblock}
  \end{postercol}

  \begin{postercol}
    \begin{posterhighlight}[Hlavní sdělení]
      Zde uveďte ověřený závěr vlastního projektu.
    \end{posterhighlight}

    \begin{posterblock}{Podklady}
      \begin{postertable}{Xl}
        \toprule
        Podklad & Stav \\
        \midrule
        Data projektu & K doplnění \\
        Dokumentace & K doplnění \\
        \bottomrule
      \end{postertable}
      Ukázka neobsahuje výzkumné výsledky ani vymyšlené zdroje.
    \end{posterblock}

    \begin{posterblock}{Závěr a další krok}
      Shrňte přínos, omezení a další plánovaný krok.
      Doplňte pouze údaje a zdroje, které jsou skutečně k dispozici.
    \end{posterblock}
  \end{postercol}
\end{posterlayout}
```

Pro vlastní hotový poster zástupné věty nahraď obsahem uživatele. Pokud podklady pro některou část chybějí, netvrď, že je poster obsahově dokončený.

## 9. Diagnostika a kontrolní postup

Před předáním zkontroluj:

1. Hlavní dokument je kořenový `main.tex`, načítá `nastaveni` před dokumentem a `obsah` uvnitř dokumentu.
2. Všechny klíče odpovídají výše uvedenému API, složené závorky a prostředí jsou uzavřené, procenta v běžném textu jsou `\%` a znak `&` je mimo tabulku zapsaný jako `\&`.
3. Počet `postercol` odpovídá každému layoutu, nejsou vnořené layouty ani ručně zdvojená čísla sekcí.
4. Každý použitý obrázek a font je skutečně v předávaném projektu, cesty odpovídají velikosti písmen a nejsou absolutní.
5. Každý výsledek, zdroj a QR cíl je doložený; zůstávající demonstrace jsou jako demonstrace označené.
6. Přelož projekt pomocí LuaLaTeXu; po změně QR kódů, odkazů či pozičních údajů proveď další průchod. Místní kontrola může použít `lualatex -interaction=nonstopmode -halt-on-error main.tex` dvakrát z kořene rozbaleného projektu. Nepřidávej tyto lokální příkazy jako nutnou součást práce uživatele v Overleafu.
7. Přečti chyby a varování. Úspěšné vytvoření PDF samo o sobě nepotvrzuje správnou sazbu.
8. Otevři či vyrenderuj celé výsledné PDF. Zkontroluj jednu zamýšlenou stránku, formát a orientaci, čitelnost, všechny číslice výsledků, popisky, konce sloupců, zápatí a nepřekrývající se QR řádek. Pokud nemáš možnost vizuální kontroly, výslovně to uveď.

| Hláška nebo příznak | Co opravit |
| --- | --- |
| Chyba `fontspec` při pdfLaTeXu | Zvolit LuaLaTeX; neodstraňovat fonty, aby chyba zmizela. |
| Chybějící soubor obrázku nebo fontu | Ověřit přibalení, přesnou cestu, příponu a velikost písmen. |
| `Wrong number of postercol environments` | Sjednotit počet skutečných sloupců a `columns`. |
| `Too many postercol environments` | Odstranit nadbytečný sloupec nebo výslovně upravit počet na 2/3/4. |
| `Nested posterlayout` nebo `Nested postercol` | Ukončit současné prostředí; nevnořovat mřížky. |
| `Column ... exceeds available poster height` | Upravit konkrétní sloupec: zkrátit text, zmenšit obrázek, rozdělit obsah nebo použít kompaktní mezery. |
| `Layout height exceeds available poster height` | Zkontrolovat ruční výšku a předchozí obsah; obvykle použít `height=auto`. |
| `Requested layout height is smaller than its content` | Odstranit nepřiměřeně malou pevnou výšku; obsah se automaticky nezmenšuje. |
| `Overfull` nebo nečekaná druhá strana | Najít skutečný přesah a opravit sazbu; nevydávat PDF za hotové jen proto, že vzniklo. |
| Nepodporované poznámky pod čarou | Použít `\postersource` nebo samostatnou sekci Literatura. |

Při předání napiš, co se změnilo a co bylo skutečně ověřeno. Místní překlad z rozbaleného ZIPu označ jako místní překlad. **Netvrď, že projekt byl zkompilován přímo v Overleafu, pokud k tomu nemáš skutečný přístup a ověřený výsledek.** Pouhé otevření stránky či stažení archivu není online kompilace.

## 10. Přenositelný prompt pro další AI

K zahájení spolupráce stačí přiložit tento dokument a případně přidat následující krátkou zprávu. Téma, podklady a další požadavky mohou přijít až v dalších zprávách:

```text
Přečti si přiložený návod a používej jej pro naši spolupráci
na TULPosteru. Budu ti postupně říkat, co chci vytvořit nebo změnit.
Zatím jen potvrď, že jsi připravená; potom ti popíšu svůj záměr.
Ptej se postupně jen na potřebné věci a drž se aktuálního zadání.
```

Není nutné používat tento text doslova. Rozhodující je skutečný požadavek zadavatele v konverzaci. Pokud uživatel hned přiloží konkrétní úkol, splň jej bez čekání na další zahájení.
