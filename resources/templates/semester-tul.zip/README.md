# Semestrální šablona TUL 1.3

Verze 1.3 (20. 10. 2026) přidává celouniverzitní variantu TUL bez fakulty
a variantu CXI. Výchozí součást je TUL, kterou v semestrální šabloně vyberete
příkazem \Fakulta{TUL}; pro ústav použijte \Fakulta{CXI}. TUL má původní
fialovou barvu, CXI červenou, obě varianty používají dodané vektorové značky.
Patička TUL neopakuje název univerzity a používá www.tul.cz.

Titulní strana zachovává rozvržení verze 1.2: hlavní název práce,
menší předmět, společný horní pás logotypu a symbolu, krátký fakultní barevný
akcent a zarovnané údaje o autorovi, datu a verzi zadání. Použitý software se
na titulce neuvádí. Vnitřní stránky zachovávají sazbu verze 1.1.

Otevřete semestralni-prace.tex, vyberte součást a nahraďte ukázkové údaje.
Součásti: TUL (celá univerzita bez fakulty), FS, FT, FP, EF, FUA, FM, FZS a CXI
(Ústav pro nanomateriály, pokročilé technologie a inovace). Případné zalomení názvu lze vložit
příkazem \\. Delší jméno se zalomí v bloku údajů.

Do Overleafu nahrajte celý ZIP jako nový projekt; hlavní soubor je
semestralni-prace.tex a kompilátor pdfLaTeX. Instalace fontů TUL Mono
není nutná: původní fakultní loga jsou vektorová PDF ve složce podklady.
Nový import této verze do Overleafu nebyl samostatně ověřen.

Lokální překlad s bibliografií:

    pdflatex semestralni-prace.tex
    bibtex semestralni-prace
    pdflatex semestralni-prace.tex
    pdflatex semestralni-prace.tex

Zdroje ukládejte do literatura.bib vedle hlavního dokumentu (export BibTeX).
Použijte \cite{klic}; seznam obsahuje citované záznamy. Přiložená bibliografie
obsahuje pouze výslovně označený smyšlený příklad a musí být nahrazena.
Pokud zdroje nepotřebujete, odstraňte ukázkovou citaci i příkazy
\bibliographystyle a \bibliography; pak stačí pdfLaTeX dvakrát.
Číselné citace unsrt samy nepotvrzují soulad s ČSN ISO 690.

Grafické podklady, barvy a adresy: veřejný balík tul 2.3 Pavla Satrapy
(2025, licence CC BY dle balíku), https://www.nti.tul.cz/~satrapa/vyuka/latex-tul/.
Původní soubory a dokumentace ve složce podklady zůstávají beze změn.
Rozvržení šablony: Adam Kábrt ve spolupráci s Codexem.
Formální požadavky konkrétního předmětu ověřte u vyučujícího.
