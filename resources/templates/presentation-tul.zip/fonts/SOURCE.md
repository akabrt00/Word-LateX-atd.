Official Inter 4.1 static fonts
Source: https://rsms.me/inter/download/
Release: https://github.com/rsms/inter/releases/download/v4.1/Inter-4.1.zip
Original SIL Open Font License is preserved in fonts/LICENSE.txt.
Four static OTF files were copied without changing their contents and renamed:
Inter-Regular.otf -> Inter.otf
Inter-Bold.otf -> Inter Bold.otf
Inter-Italic.otf -> Inter Italic.otf
Inter-BoldItalic.otf -> Inter BoldItalic.otf
The main TeX files load these files directly through fontspec.
No Windows font installation is required. These are exercise project assets.
