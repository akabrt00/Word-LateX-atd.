# Ověřený cvičný projekt prezentace

Datum: 2026-10-04. Cvičné údaje a věty nahraďte vlastními.

- main.tex: tři snímky 16:9.
- main-43.tex: tři snímky 4:3.
- main-handout-letter.tex: tři snímky na dvou listech Letter.
- main-handout-a4.tex: tři snímky na dvou listech A4.

Nahrajte celý projekt do Overleafu, vyberte XeLaTeX a právě jeden hlavní soubor. Overleaf nebyl přímo ověřen; místní Tectonic 0.17.0 všechny čtyři soubory sestavil. Přiložené stejnojmenné PDF dokládají kontrolovaný výsledek.

Původní třída a všech deset souborů veřejného ZIPu jsou beze změny. Manuál zůstal v projektu pro orientaci; hlavní soubor je main.tex. Původní README obsahuje údaje o autorovi a licenci. Font Inter 4.1 pochází z https://github.com/rsms/inter/releases/download/v4.1/Inter-4.1.zip (https://rsms.me/inter/download/). Čtyři skutečné statické řezy byly pouze přejmenovány pro přímé načtení; licence SIL OFL a záznam původu jsou ve fonts/.

Varování původní třídy: zastaralé hooky, nepoužité globální volby a fontová varianta TULMono Bold (použit dodaný font). Krátký příklad nemá hlášené overfull boxy ani chybějící znaky. Historický distribuovaný manuál PDF má 30stran, aktuální zdroj 13snímků; historické PDF tedy není přesný výstup ověřeného zdroje.
